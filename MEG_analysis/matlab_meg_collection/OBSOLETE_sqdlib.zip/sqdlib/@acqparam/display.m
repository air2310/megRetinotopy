function display(t)
% DISPLAY Display object properties

for i = 1:length(t)
    get(t(i));
end;